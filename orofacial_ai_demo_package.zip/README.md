
# Orofacial AI Diagnostic Demo

This repository contains a minimal, demo-ready version of a hybrid AI model for differentiating endodontic vs non-endodontic orofacial pain.

## 📄 Description

This demo includes:
- A synthetic dataset that mimics real clinical records
- A basic machine learning pipeline using a Random Forest classifier
- Example training and inference scripts

> ⚠️ **Note**: The dataset is synthetic and not for clinical use. It is intended for replicability and demonstration only.

## 📂 Files

- `synthetic_orofacial_ai_dataset.csv`: Sample data with demographic, clinical, and diagnostic variables.
- `train_model.py`: Trains a simple Random Forest model.
- `inference.py`: Performs prediction on new data.

## 🧪 Requirements

- Python 3.x
- pandas
- scikit-learn

Install requirements:
```bash
pip install pandas scikit-learn
```

## 🚀 Quick Start

```bash
python train_model.py
python inference.py
```

## 🔐 License

MIT License

## 🤝 Citation

If you use this demo, please cite the original study:

> Karobari MI, et al. Development and Validation of a Predictive AI Model for Differential Diagnosis of Endodontic and Non-Endodontic Orofacial Pain. [Journal Name], 2024.
