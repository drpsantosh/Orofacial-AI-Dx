
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load dataset
df = pd.read_csv("synthetic_orofacial_ai_dataset.csv")

# Preprocess
df['Sex'] = df['Sex'].map({'Male': 0, 'Female': 1})
df['PainType'] = df['PainType'].map({'Sharp': 0, 'Dull': 1, 'Throbbing': 2})
df['Diagnosis'] = df['Diagnosis'].map({'Endodontic': 1, 'Non-Endodontic': 0})

X = df.drop(columns=['Diagnosis'])
y = df['Diagnosis']

# Train model
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X, y)

# Save model
joblib.dump(clf, "orofacial_rf_model.pkl")
print("Model trained and saved as orofacial_rf_model.pkl")
