
import pandas as pd
import joblib

# Load model
model = joblib.load("orofacial_rf_model.pkl")

# Example new input
sample = pd.DataFrame([{
    'Age': 45,
    'Sex': 0,
    'PainDuration_days': 16.5,
    'RadiographicLesion': 1,
    'PulpVitalityTest_Positive': 0,
    'PainType': 0
}])

# Predict
prediction = model.predict(sample)
print("Predicted Diagnosis (1=Endodontic, 0=Non-Endodontic):", prediction[0])
